package com.vanch.vhxdemo;

public enum Status {
	ON,
//	OFF,
	BAD,
	INCOMPLETE
}